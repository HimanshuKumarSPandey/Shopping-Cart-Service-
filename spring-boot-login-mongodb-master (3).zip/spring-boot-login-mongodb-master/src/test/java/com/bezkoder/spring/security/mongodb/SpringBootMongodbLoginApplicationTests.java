package com.bezkoder.spring.security.mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMongodbLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
